import React, { useState, useEffect } from 'react';
import { DragDropContext } from 'react-beautiful-dnd';
import ResearchGrid from './components/ResearchGrid';
import researchData from './data/research.json';

function App() {
  const [research, setResearch] = useState([]);

  useEffect(() => {
    setResearch(researchData);
  }, []);

  const onDragEnd = (result) => {
    // Implement drag and drop logic here
  };

  return (
    <div className="App">
      <h1>Empire Research</h1>
      <DragDropContext onDragEnd={onDragEnd}>
        <ResearchGrid research={research} />
      </DragDropContext>
    </div>
  );
}

export default App;