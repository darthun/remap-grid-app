import React from 'react';
import Tier from './Tier';
import Category from './Category';

function ResearchGrid({ research }) {
  const tiers = [1, 2, 3, 4, 5];

  return (
    <div className="research-grid">
      <div className="tiers">
        {tiers.map(tier => (
          <Tier key={tier} tier={tier} research={research.filter(r => r.tier === tier)} />
        ))}
      </div>
      <div className="categories">
        {/* Implement categories here */}
      </div>
    </div>
  );
}

export default ResearchGrid;