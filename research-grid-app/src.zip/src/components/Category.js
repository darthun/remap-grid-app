import React from 'react';
import { Droppable } from 'react-beautiful-dnd';
import ResearchItem from './ResearchItem';

function Category({ category, research }) {
  return (
    <div className="category">
      <h2>{category.name}</h2>
      <Droppable droppableId={`category-${category.id}`}>
        {(provided) => (
          <div ref={provided.innerRef} {...provided.droppableProps}>
            {research.map((item, index) => (
              <ResearchItem key={item.id} item={item} index={index} />
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}

export default Category;