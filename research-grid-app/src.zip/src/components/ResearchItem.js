import React from 'react';
import { Draggable } from 'react-beautiful-dnd';

function ResearchItem({ item, index }) {
  return (
    <Draggable draggableId={item.id} index={index}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
        >
          <img src={item.image} alt={item.name} />
          <p>{item.name}</p>
        </div>
      )}
    </Draggable>
  );
}

export default ResearchItem;