import React from 'react';
import { Droppable } from 'react-beautiful-dnd';
import ResearchItem from './ResearchItem';

function Tier({ tier, research }) {
  return (
    <div className="tier">
      <h2>Tier {tier}</h2>
      <Droppable droppableId={`tier-${tier}`}>
        {(provided) => (
          <div ref={provided.innerRef} {...provided.droppableProps}>
            {research.map((item, index) => (
              <ResearchItem key={item.id} item={item} index={index} />
            ))}
            {provided.placeholder}
          </div>
        )}
      </Droppable>
    </div>
  );
}

export default Tier;